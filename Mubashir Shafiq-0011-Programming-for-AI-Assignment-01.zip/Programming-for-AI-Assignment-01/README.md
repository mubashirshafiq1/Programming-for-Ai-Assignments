# Programming for AI (Lab) - Assignment 01

**Department of Computing and Innovation, Riphah International University Sahiwal**
Course: Lab of Programming for AI | Semester/Section: FA 25 BS AI - B
Instructor: Muhammad Usama Arshad | Assignment No. 01

Five beginner-level Python programs covering dictionaries, lists, sets, strings,
functions, loops, conditions and file handling.

## Project Structure

```
Programming-for-AI-Assignment-01/
├── q1_student_result_system.py   # Student result management system
├── q2_word_analysis.py           # Sentence / word analysis
├── q3_shopping_bill.py           # Shopping bill with discount
├── q4_calculator.py              # Menu-driven calculator
├── q5_restaurant.py              # Restaurant ordering system
├── sample_output/                # Example files produced by the programs
│   ├── results.txt
│   ├── word_analysis.txt
│   ├── bill.txt
│   └── orders.txt
├── .gitignore
└── README.md
```

## How to Run

Requires Python 3.6 or newer (no extra libraries needed).

```bash
python q1_student_result_system.py
python q2_word_analysis.py
python q3_shopping_bill.py
python q4_calculator.py
python q5_restaurant.py
```

Output files are created in the same folder as the script.

## Summary of Each Question

| Q  | Program | What it does | Output file |
|----|---------|--------------|-------------|
| 1 | `q1_student_result_system.py` | Takes name, roll no. and marks (Python, AI, Maths) of 5 students, stores each in a dictionary inside a list, calculates total / percentage / grade with a function, shows all results, finds the topper | `results.txt` |
| 2 | `q2_word_analysis.py` | Counts words, characters, vowels; finds longest and shortest word; builds a set of unique words and shows them alphabetically | `word_analysis.txt` |
| 3 | `q3_shopping_bill.py` | Takes 5 products (name, price, quantity), calculates each total and the bill, gives 10% discount above Rs. 10,000, shows the most expensive product | `bill.txt` |
| 4 | `q4_calculator.py` | Calculator for + - * / % using if/elif/else and separate functions; repeats until the user exits | - |
| 5 | `q5_restaurant.py` | Menu-based ordering with quantities, multiple items, final bill | `orders.txt` |

## Notes

- Marks must be between 0 and 100; invalid input is asked again.
- Percentage in Q1 = total / 300 x 100.
- Q2: punctuation is stripped from words; if two words have the same length, the first one is shown as longest/shortest. "Total characters" includes spaces (the count without spaces is also shown).
- Q3: the most expensive product is decided by unit price.
- Q4: division and modulus by zero show an error message instead of crashing.
- Q5: new orders are appended to `orders.txt`, so earlier customers' bills are kept.

## Pushing to GitHub

```bash
cd Programming-for-AI-Assignment-01
git init
git add .
git commit -m "Add Programming for AI Assignment 01 solutions"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```
