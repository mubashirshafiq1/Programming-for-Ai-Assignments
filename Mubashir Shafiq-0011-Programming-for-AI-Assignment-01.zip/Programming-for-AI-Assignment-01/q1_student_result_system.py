"""
Q1 - Student Result Management System
Lab of Programming for AI - Assignment 01
"""

import os

SUBJECTS = ["Python", "Artificial Intelligence", "Mathematics"]
NUM_STUDENTS = 5
OUTPUT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results.txt")


def get_marks(subject):
    """Keep asking until the user enters marks between 0 and 100."""
    while True:
        try:
            marks = float(input(f"  Enter marks for {subject} (0-100): "))
            if 0 <= marks <= 100:
                return marks
            print("  Marks must be between 0 and 100. Try again.")
        except ValueError:
            print("  Invalid input. Please enter a number.")


def calculate_result(student):
    """Calculate total marks, percentage and grade for one student."""
    total = sum(student["marks"].values())
    max_marks = len(student["marks"]) * 100
    percentage = (total / max_marks) * 100

    if percentage >= 80:
        grade = "A"
    elif percentage >= 70:
        grade = "B"
    elif percentage >= 60:
        grade = "C"
    elif percentage >= 50:
        grade = "D"
    else:
        grade = "F"

    return total, percentage, grade


def build_table(students):
    """Return the result table as a list of text lines."""
    lines = []
    header = (f"{'Roll No':<10}{'Name':<18}{'Python':>8}{'AI':>8}{'Maths':>8}"
              f"{'Total':>9}{'Percent':>10}{'Grade':>7}")
    lines.append(header)
    lines.append("-" * len(header))
    for s in students:
        m = s["marks"]
        lines.append(
            f"{s['roll_no']:<10}{s['name']:<18}"
            f"{m['Python']:>8.1f}{m['Artificial Intelligence']:>8.1f}{m['Mathematics']:>8.1f}"
            f"{s['total']:>9.1f}{s['percentage']:>9.2f}%{s['grade']:>7}"
        )
    return lines


def main():
    students = []
    used_rolls = set()

    print("=== Student Result Management System ===")
    for i in range(1, NUM_STUDENTS + 1):
        print(f"\nStudent {i} of {NUM_STUDENTS}")

        name = ""
        while not name:
            name = input("  Enter name: ").strip()

        roll_no = ""
        while not roll_no or roll_no in used_rolls:
            roll_no = input("  Enter roll number: ").strip()
            if roll_no in used_rolls:
                print("  This roll number is already used. Enter a different one.")
        used_rolls.add(roll_no)

        marks = {}
        for subject in SUBJECTS:
            marks[subject] = get_marks(subject)

        student = {"name": name, "roll_no": roll_no, "marks": marks}
        total, percentage, grade = calculate_result(student)
        student["total"] = total
        student["percentage"] = percentage
        student["grade"] = grade
        students.append(student)

    # Show all results
    table = build_table(students)
    print("\n=== Results of All Students ===")
    for line in table:
        print(line)

    # Find the topper
    topper = max(students, key=lambda s: s["percentage"])
    topper_text = (f"Highest percentage: {topper['name']} (Roll No: {topper['roll_no']}) "
                   f"- {topper['percentage']:.2f}% - Grade {topper['grade']}")
    print("\n" + topper_text)

    # Save to file
    with open(OUTPUT_FILE, "w") as f:
        f.write("STUDENT RESULTS\n\n")
        f.write("\n".join(table))
        f.write("\n\n" + topper_text + "\n")
    print(f"\nResults saved to {os.path.basename(OUTPUT_FILE)}")


if __name__ == "__main__":
    main()
