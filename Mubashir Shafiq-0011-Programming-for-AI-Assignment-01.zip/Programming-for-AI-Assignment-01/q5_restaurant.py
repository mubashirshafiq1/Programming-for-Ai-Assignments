"""
Q5 - Small Restaurant Ordering Program
Lab of Programming for AI - Assignment 01
"""

import os

MENU = {
    1: {"name": "Burger", "price": 500},
    2: {"name": "Pizza", "price": 800},
    3: {"name": "Fries", "price": 250},
    4: {"name": "Drink", "price": 150},
}
OUTPUT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "orders.txt")


def show_menu():
    print("\n----- MENU -----")
    for number, item in MENU.items():
        print(f"{number}. {item['name']:<8} Rs. {item['price']}")
    print("0. Finish order")


def read_choice():
    """Return the menu number chosen by the user (0 to finish)."""
    while True:
        try:
            choice = int(input("Select an item number: "))
            if choice == 0 or choice in MENU:
                return choice
            print("Please choose a number from the menu.")
        except ValueError:
            print("Invalid input. Enter a number.")


def read_quantity():
    while True:
        try:
            qty = int(input("Enter quantity: "))
            if qty > 0:
                return qty
            print("Quantity must be at least 1.")
        except ValueError:
            print("Invalid input. Enter a whole number.")


def calculate_bill(order):
    """order is a dict: item name -> {'price': .., 'quantity': ..}"""
    total = 0
    for item in order.values():
        total += item["price"] * item["quantity"]
    return total


def build_bill_text(order, total):
    lines = ["RESTAURANT BILL", "=" * 44]
    lines.append(f"{'Item':<12}{'Price':>8}{'Qty':>6}{'Amount':>14}")
    lines.append("-" * 44)
    for name, item in order.items():
        amount = item["price"] * item["quantity"]
        lines.append(f"{name:<12}{item['price']:>8}{item['quantity']:>6}{amount:>14}")
    lines.append("-" * 44)
    lines.append(f"{'TOTAL BILL:':<26}Rs. {total:>10}")
    return "\n".join(lines)


def save_bill(bill_text):
    """Append the bill so earlier customers' orders are not lost."""
    with open(OUTPUT_FILE, "a") as f:
        f.write(bill_text + "\n\n")


def main():
    print("=== Welcome to Our Restaurant ===")
    order = {}

    while True:
        show_menu()
        choice = read_choice()
        if choice == 0:
            if order:
                break
            print("You have not ordered anything yet.")
            continue

        item = MENU[choice]
        qty = read_quantity()

        if item["name"] in order:
            order[item["name"]]["quantity"] += qty
        else:
            order[item["name"]] = {"price": item["price"], "quantity": qty}
        print(f"Added {qty} x {item['name']}")

        more = input("Order something else? (yes/no): ").strip().lower()
        if more not in ("yes", "y"):
            break

    total = calculate_bill(order)
    bill_text = build_bill_text(order, total)
    print("\n" + bill_text)

    save_bill(bill_text)
    print(f"\nBill saved to {os.path.basename(OUTPUT_FILE)}")


if __name__ == "__main__":
    main()
