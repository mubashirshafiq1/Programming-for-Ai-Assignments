"""
Q4 - Calculator
Lab of Programming for AI - Assignment 01
"""


def add(a, b):
    return a + b


def subtract(a, b):
    return a - b


def multiply(a, b):
    return a * b


def divide(a, b):
    if b == 0:
        return "Error: cannot divide by zero"
    return a / b


def modulus(a, b):
    if b == 0:
        return "Error: cannot take modulus with zero"
    return a % b


def read_number(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Invalid input. Please enter a number.")


def main():
    print("=== Simple Calculator ===")

    while True:
        num1 = read_number("\nEnter first number: ")
        num2 = read_number("Enter second number: ")

        print("\nSelect operation:")
        print("  +  Addition")
        print("  -  Subtraction")
        print("  *  Multiplication")
        print("  /  Division")
        print("  %  Modulus")
        op = input("Your choice: ").strip()

        if op == "+":
            result = add(num1, num2)
        elif op == "-":
            result = subtract(num1, num2)
        elif op == "*":
            result = multiply(num1, num2)
        elif op == "/":
            result = divide(num1, num2)
        elif op == "%":
            result = modulus(num1, num2)
        else:
            result = None
            print("Invalid operation selected.")

        if result is not None:
            print(f"\nResult: {num1} {op} {num2} = {result}")

        again = input("\nDo you want to perform another calculation? (yes/no): ").strip().lower()
        if again not in ("yes", "y"):
            print("Thank you for using the calculator. Goodbye!")
            break


if __name__ == "__main__":
    main()
