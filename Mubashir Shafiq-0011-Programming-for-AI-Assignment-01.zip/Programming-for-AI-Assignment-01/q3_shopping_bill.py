"""
Q3 - Simple Shopping Program
Lab of Programming for AI - Assignment 01
"""

import os

NUM_PRODUCTS = 5
DISCOUNT_LIMIT = 10000
DISCOUNT_RATE = 0.10
OUTPUT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bill.txt")


def read_number(prompt, number_type):
    """Read a positive number (int or float) from the user."""
    while True:
        try:
            value = number_type(input(prompt))
            if value > 0:
                return value
            print("  Value must be greater than 0.")
        except ValueError:
            print("  Invalid input. Please enter a valid number.")


def calculate_bill(products):
    """Return (subtotal, discount, final_bill) for the list of products."""
    subtotal = 0
    for p in products:
        p["total"] = p["price"] * p["quantity"]
        subtotal += p["total"]

    discount = 0
    if subtotal > DISCOUNT_LIMIT:
        discount = subtotal * DISCOUNT_RATE

    return subtotal, discount, subtotal - discount


def build_bill_text(products, subtotal, discount, final_bill, expensive):
    lines = []
    lines.append("SHOPPING BILL")
    lines.append("=" * 52)
    lines.append(f"{'Product':<18}{'Price':>10}{'Qty':>7}{'Total':>14}")
    lines.append("-" * 52)
    for p in products:
        lines.append(f"{p['name']:<18}{p['price']:>10.2f}{p['quantity']:>7}{p['total']:>14.2f}")
    lines.append("-" * 52)
    lines.append(f"{'Subtotal:':<35}Rs. {subtotal:>10.2f}")
    if discount > 0:
        lines.append(f"{'Discount (10%):':<35}Rs. {discount:>10.2f}")
    else:
        lines.append(f"{'Discount:':<35}Rs. {0:>10.2f}")
    lines.append(f"{'FINAL BILL:':<35}Rs. {final_bill:>10.2f}")
    lines.append("")
    lines.append(f"Most expensive product: {expensive['name']} (Rs. {expensive['price']:.2f} per unit)")
    return "\n".join(lines)


def main():
    products = []
    print("=== Shopping Program ===")
    print(f"Enter details of {NUM_PRODUCTS} products.\n")

    for i in range(1, NUM_PRODUCTS + 1):
        print(f"Product {i}")
        name = ""
        while not name:
            name = input("  Name: ").strip()
        price = read_number("  Price (Rs.): ", float)
        quantity = read_number("  Quantity: ", int)

        # each product is stored in a dictionary
        products.append({"name": name, "price": price, "quantity": quantity, "total": 0})

    subtotal, discount, final_bill = calculate_bill(products)
    expensive = max(products, key=lambda p: p["price"])

    bill_text = build_bill_text(products, subtotal, discount, final_bill, expensive)
    print("\n" + bill_text)

    with open(OUTPUT_FILE, "w") as f:
        f.write(bill_text + "\n")
    print(f"\nBill saved to {os.path.basename(OUTPUT_FILE)}")


if __name__ == "__main__":
    main()
