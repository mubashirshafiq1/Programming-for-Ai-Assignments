"""
Q2 - Sentence / Word Analysis
Lab of Programming for AI - Assignment 01
"""

import os
import string

OUTPUT_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "word_analysis.txt")


def get_words(sentence):
    """Split the sentence into words and remove punctuation around them."""
    words = []
    for w in sentence.split():
        w = w.strip(string.punctuation)
        if w:
            words.append(w)
    return words


def count_vowels(sentence):
    vowels = "aeiouAEIOU"
    count = 0
    for ch in sentence:
        if ch in vowels:
            count += 1
    return count


def analyse(sentence):
    """Run all the analysis and return the results in a dictionary."""
    words = get_words(sentence)
    unique_words = set(w.lower() for w in words)

    return {
        "sentence": sentence,
        "total_words": len(words),
        "total_chars": len(sentence),
        "chars_no_spaces": len(sentence.replace(" ", "")),
        "longest": max(words, key=len),
        "shortest": min(words, key=len),
        "vowels": count_vowels(sentence),
        "unique_words": unique_words,
        "sorted_words": sorted(unique_words),
    }


def build_report(r):
    lines = [
        "WORD ANALYSIS REPORT",
        "=" * 40,
        f"Sentence             : {r['sentence']}",
        f"Total words          : {r['total_words']}",
        f"Total characters     : {r['total_chars']} (including spaces)",
        f"Characters (no space): {r['chars_no_spaces']}",
        f"Longest word         : {r['longest']}",
        f"Shortest word        : {r['shortest']}",
        f"Number of vowels     : {r['vowels']}",
        f"Unique words (set)   : {r['unique_words']}",
        f"Alphabetical order   : {', '.join(r['sorted_words'])}",
    ]
    return "\n".join(lines)


def main():
    sentence = ""
    while not get_words(sentence):
        sentence = input("Enter a sentence: ").strip()
        if not get_words(sentence):
            print("Please enter at least one word.")

    result = analyse(sentence)
    report = build_report(result)

    print("\n" + report)

    with open(OUTPUT_FILE, "w") as f:
        f.write(report + "\n")
    print(f"\nAnalysis saved to {os.path.basename(OUTPUT_FILE)}")


if __name__ == "__main__":
    main()
